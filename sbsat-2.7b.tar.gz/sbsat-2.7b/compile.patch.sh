#!/bin/sh

patch -f -p1 $1 < compile.patch
